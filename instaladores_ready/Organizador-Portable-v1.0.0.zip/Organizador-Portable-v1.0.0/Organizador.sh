#!/bin/bash

# Ejecutar Organizador en Linux/Mac

# Verificar si Python está instalado
if ! command -v python3 &> /dev/null; then
    echo ""
    echo "ERROR: Python 3 no está instalado"
    echo ""
    echo "Para instalar Python 3:"
    echo "Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "Fedora: sudo dnf install python3"
    echo "Mac: brew install python3"
    echo ""
    exit 1
fi

# Instalar dependencias (solo la primera vez)
if [ ! -d "venv" ]; then
    echo "Instalando dependencias (primera ejecución)..."
    python3 -m pip install -q -r requirements.txt
fi

# Ejecutar la aplicación
echo "Iniciando Organizador..."
python3 run.py

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Hubo un problema al ejecutar la aplicación"
    echo "Por favor, intenta nuevamente o contacta al soporte"
    echo ""
fi
