@echo off
REM Ejecutar Organizador en Windows

REM Verificar si Python está instalado
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Python no está instalado o no está en el PATH
    echo.
    echo Para instalar Python:
    echo 1. Descarga desde: https://www.python.org/downloads/
    echo 2. Durante la instalación, marca "Add Python to PATH"
    echo 3. Reinicia tu computadora
    echo 4. Intenta ejecutar Organizador nuevamente
    echo.
    pause
    exit /b 1
)

REM Instalar dependencias (solo la primera vez)
if not exist venv (
    echo Instalando dependencias (primera ejecución)...
    python -m pip install -q -r requirements.txt
)

REM Ejecutar la aplicación
echo Iniciando Organizador...
python run.py

if %errorlevel% neq 0 (
    echo.
    echo ERROR: Hubo un problema al ejecutar la aplicación
    echo Por favor, intenta nuevamente o contacta al soporte
    echo.
    pause
)
